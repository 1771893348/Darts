package com.example.jmf.timetest;

import android.annotation.SuppressLint;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.jmf.timetest.view.DartTarget;

import java.io.IOException;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;

import static com.example.jmf.timetest.R.id.dart_target;
@SuppressLint("NewApi")
public class MainActivity extends AppCompatActivity {

    private DartTarget dart_target;
    private Random mRandom;
    private String[] scoreArea={"20","1","18","4","13","6","10","15","2","17","3","19","7","16","8","11","14","9","12","5","25","50","0"};
    private String[] scoreMultiple = {"a","b","c","d"};
    private MyThread mThread;
    private MediaPlayerSound mMediaPlayerSound;
    public MediaPlayer mediaPlayer; // 媒体播放器
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mRandom = new Random();
        dart_target = (DartTarget) findViewById(R.id.dart_target);
        mThread = new MyThread();
        mMediaPlayerSound = new MediaPlayerSound(this);
        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);// 设置媒体流类型
        dart_target.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
//                dart_target.setHighlight("25","",0);
                if (!mThread.getThreadState()){
                    mThread.setThreadState(true);
                    mThread.start();
                    AssetFileDescriptor afd = null;
                    try {
                        afd = getAssets().openFd("broadcast/bj_music.MP3");
                        mediaPlayer.reset();
                        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                        mediaPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
                        mediaPlayer.prepare();
                        mediaPlayer.setLooping(true);
                        mediaPlayer.start();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
//                else {
//                    mThread.stopLight();
//                }
//                dart_target.setHighlight("0","a");
            }
        });
    }

    private class MyThread extends Thread{
        private AtomicBoolean mQuit = new AtomicBoolean(false);
        int indexCount = 0;
        String mScore = "0";
        String mTimes = "0";
        public void stopLight(){
            mQuit.set(false);
        }
        public boolean getThreadState(){
            return mQuit.get();
        }
        public void setThreadState(boolean state){
            mQuit.set(state);
        }
        @Override
        public void run() {
            super.run();
            while (mQuit.get()){
                int index = mRandom.nextInt(scoreArea.length);
                int indexMul = mRandom.nextInt(scoreMultiple.length);
                mScore = scoreArea[index];
                mTimes = scoreMultiple[indexMul];
                dart_target.setHighlight(mScore,mTimes,0);
                indexCount++;
                if (indexCount>38){
                    stopLight();
                }
                try {
                    sleep(200);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            mediaPlayer.stop();
            int sore = Integer.parseInt(mScore);
            indexCount = 0;
            if (sore%25!=0){
                switch (mTimes){
                    case "b":
                        sore = sore * 3;
                        break;
                    case "d":
                        sore = sore * 2;
                        break;
                }
            }

            mMediaPlayerSound.playAssertsFile(new MediaPlayerSound.MediaSoundCallBack() {
                @Override
                public void onSoundAllComplete() {

                }
            },sore);
        }
    };
}
